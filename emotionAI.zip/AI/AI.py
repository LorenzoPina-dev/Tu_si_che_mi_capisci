import importlib
import librosa
import numpy as np 
import matplotlib.pyplot as plt
import tensorflow as tf
import matplotlib.pyplot as specgram
import pandas as pd 
import glob 
from sklearn.metrics import confusion_matrix
import IPython.display as ipd  # To play sound in the notebooks
import os
import sys
import warnings
if not sys.warnoptions:
    warnings.simplefilter("ignore")
warnings.filterwarnings("ignore", category=DeprecationWarning) 

#files path 
SAVEE = "E:\marini alessio\gestioneProgetto\SAVEE\ALL"

#print some files
dir_list = os.listdir(SAVEE)
#print(dir_list[0:5])

# parse the filename to get the emotions
emotion = []
path = []
for i in dir_list:
    if i[-8:-6]=='_a':
        emotion.append('male_angry')
    elif i[-8:-6]=='_d':
        emotion.append('male_disgust')
    elif i[-8:-6]=='_f':
        emotion.append('male_fear')
    elif i[-8:-6]=='_h':
        emotion.append('male_happy')
    elif i[-8:-6]=='_n':
        emotion.append('male_neutral')
    elif i[-8:-6]=='sa':
        emotion.append('male_sad')
    elif i[-8:-6]=='su':
        emotion.append('male_surprise')
    else:
        emotion.append('male_error') 
    path.append(SAVEE + i)

SAVEE_df = pd.DataFrame(emotion, columns = ['labels'])
SAVEE_df['source'] = 'SAVEE'
SAVEE_df = pd.concat([SAVEE_df, pd.DataFrame(path, columns = ['path'])], axis = 1)
SAVEE_df.labels.value_counts()